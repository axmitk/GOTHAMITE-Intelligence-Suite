"""
GOTHAMITE Streamlit frontend package.
"""
