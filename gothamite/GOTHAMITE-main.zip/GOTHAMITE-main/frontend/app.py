import sys
from pathlib import Path

# Ensure repository root is on sys.path for both local streamlit run and container execution
REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import streamlit as st
import pandas as pd
from datetime import datetime

try:
    from frontend.api_client import (
        get_graph,
        trigger_correlation,
        get_sources_metrics,
        format_score_badge,
    )
except ModuleNotFoundError:
    from api_client import (
        get_graph,
        trigger_correlation,
        get_sources_metrics,
        format_score_badge,
    )

st.set_page_config(
    page_title="GOTHAMITE | Threat Actor Correlation Platform",
    page_icon="🦇",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("🦇 GOTHAMITE")
st.caption(
    "**Cross-Source Dark Web Threat Actor De-Anonymization Platform** | "
    "*Deterministic Attribution · Auditable Evidence Provenance · Contradiction-Aware Scoring*"
)
st.markdown("---")

# Header action & correlation trigger
col_title, col_btn = st.columns([3, 1])
with col_title:
    st.subheader("Intelligence Overview & Operational Health")
with col_btn:
    if st.button("⚡ Run Correlation Pass", type="primary", use_container_width=True):
        with st.spinner("Executing deterministic correlation pass across all monitored sources..."):
            res = trigger_correlation()
            st.success(
                f"Correlation pass complete! Evaluated {res.get('evaluated_pairs', 0)} pairs, "
                f"Active relationships: {res.get('active_relationships', 0)}"
            )
            st.rerun()

# Load graph and system metrics
graph_data = get_graph()
sources_data = get_sources_metrics()

total_artifacts = sum(s["artifacts_count"] for s in sources_data)
total_personas = len(graph_data.get("nodes", []))
total_relationships = len(graph_data.get("edges", []))
active_links = sum(1 for e in graph_data.get("edges", []) if e.get("type") == "same_actor_suspected")
transacted_links = sum(1 for e in graph_data.get("edges", []) if e.get("type") == "transacted_with")

# High-level Metrics Row
m1, m2, m3, m4 = st.columns(4)
m1.metric("Immutable Artifacts", f"{total_artifacts}", help="Total raw posts and listings stored with SHA-256 verification")
m2.metric("Observed Personas", f"{total_personas}", help="Unique (handle, source_id) personas recorded")
m3.metric("Suspected Actor Links", f"{active_links}", help="Cross-source links scoring >= 0.30")
m4.metric("Transaction References", f"{transacted_links}", help="Documented wallet transaction interaction edges")

st.markdown("---")

# Layout: Left column = Active Correlated Personas; Right column = Monitored Sources
c_left, c_right = st.columns([3, 2])

with c_left:
    st.markdown("### 🔗 Active Persona Linkages")
    edges = graph_data.get("edges", [])
    if not edges:
        st.info("No active relationships above threshold. Click 'Run Correlation Pass' above to evaluate.")
    else:
        rows = []
        for e in edges:
            score_val = e.get("score", 0.0)
            rows.append({
                "Persona P": e.get("from_handle"),
                "Persona Q": e.get("to_handle"),
                "Link Type": e.get("type"),
                "Confidence Score": format_score_badge(score_val),
                "Status": e.get("status", "proposed").upper(),
                "Signals Count": e.get("evidence_count", 0),
            })
        df_edges = pd.DataFrame(rows)
        st.dataframe(df_edges, use_container_width=True, hide_index=True)
        st.caption("ℹ️ Go to **1_graph** in the sidebar to inspect the full interactive force-directed graph and artifact provenance.")

with c_right:
    st.markdown("### 🌐 Monitored Onion Sources")
    if sources_data:
        df_sources = pd.DataFrame(sources_data)
        st.dataframe(
            df_sources[[
                "source_id", "type", "reliability", "status", "personas_count", "artifacts_count"
            ]],
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.warning("No sources recorded. Run `python scripts/seed_demo.py` to populate.")

st.markdown("---")

# Architectural Integrity Notice
with st.expander("🛡️ Application Security & Attribution Safety Notice", expanded=False):
    st.markdown(
        """
        - **Inert Data Pipeline**: All ingested posts and listings are untrusted adversarial text. Never passed to `eval()`, SQL strings, or LLM prompts.
        - **Deterministic Confidence**: Scores are arithmetic sums of verifiable digital signals, capped at **0.95**. Re-running produces identical results.
        - **Contradiction-Aware**: Opposing signals (e.g. concurrent activity windows without cryptographic keys) actively reduce confidence.
        - **Cryptographic Provenance**: Every link connects to immutable, SHA-256 hashed source artifacts in the Evidence Locker.
        - **Pseudonym Mapping**: GOTHAMITE correlates online pseudonymous handles; it does not claim real-world physical deanonymization.
        """
    )
