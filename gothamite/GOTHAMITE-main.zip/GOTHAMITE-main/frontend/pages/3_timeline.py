import sys
from pathlib import Path

# Ensure repository root is on sys.path for multi-page execution
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import streamlit as st
import pandas as pd
import altair as alt

try:
    from frontend.api_client import (
        get_all_personas,
        get_timeline_all_events,
        get_artifact,
    )
except ModuleNotFoundError:
    from api_client import (
        get_all_personas,
        get_timeline_all_events,
        get_artifact,
    )

st.set_page_config(page_title="Activity Timeline | GOTHAMITE", page_icon="⏱️", layout="wide")

st.title("⏱️ Temporal Activity Timeline & Rebrand Tracking")
st.caption("Chronological visualization of threat-actor footprints. Visualizes persona migrations, infrastructure handoffs, and activity windows.")

# Highlights banner for demo
st.info(
    "💡 **Rebrand Migration Spotlight**: Notice how `quillfeather` (forum-alpha) activity ceases on **2026-04-02**, "
    "followed immediately by `quill_v2` (forum-gamma) emerging on **2026-04-19** with the identical Bitcoin wallet (`1Kp7dR...`). "
    "This 17-day succession gap is captured deterministically at confidence **0.60** without requiring a PGP key match."
)

personas = get_all_personas()
if not personas:
    st.warning("No personas observed.")
    st.stop()

# 1. Activity Windows Gantt Chart
st.markdown("### 📊 Persona Activity Windows Across Dark Web Sources")

df_personas = pd.DataFrame(personas)
df_personas["start"] = pd.to_datetime(df_personas["first_seen"])
df_personas["end"] = pd.to_datetime(df_personas["last_seen"])

# Altair horizontal bar chart
chart = (
    alt.Chart(df_personas)
    .mark_bar(cornerRadius=6, size=24)
    .encode(
        x=alt.X("start:T", title="Observation Timeline (2026)"),
        x2="end:T",
        y=alt.Y("handle:N", title="Persona Handle", sort=alt.EncodingSortField(field="start", order="ascending")),
        color=alt.Color(
            "source_id:N",
            scale=alt.Scale(
                domain=["forum-alpha", "marketplace-beta", "forum-gamma"],
                range=["#3498db", "#e67e22", "#2ecc71"],
            ),
            title="Dark Web Source",
        ),
        tooltip=[
            alt.Tooltip("handle:N", title="Handle"),
            alt.Tooltip("source_id:N", title="Source"),
            alt.Tooltip("first_seen:N", title="First Seen"),
            alt.Tooltip("last_seen:N", title="Last Seen"),
            alt.Tooltip("post_count:Q", title="Post Count"),
        ],
    )
    .properties(height=320, width="container")
)

st.altair_chart(chart, use_container_width=True)

st.markdown("---")

# 2. Chronological Observation Stream
st.markdown("### 📜 Chronological Observation Stream")

events = get_timeline_all_events()
if not events:
    st.info("No timeline events found.")
else:
    df_events = pd.DataFrame(events)

    # Filter controls
    c1, c2 = st.columns(2)
    with c1:
        handles_filter = st.multiselect(
            "Filter by Persona:",
            options=sorted(list({e["handle"] for e in events})),
            default=[],
        )
    with c2:
        sources_filter = st.multiselect(
            "Filter by Source:",
            options=sorted(list({e["source_id"] for e in events})),
            default=[],
        )

    filtered_df = df_events.copy()
    if handles_filter:
        filtered_df = filtered_df[filtered_df["handle"].isin(handles_filter)]
    if sources_filter:
        filtered_df = filtered_df[filtered_df["source_id"].isin(sources_filter)]

    st.markdown(f"**Showing {len(filtered_df)} observation events:**")

    for _, row in filtered_df.iterrows():
        with st.container(border=True):
            col_meta, col_val = st.columns([1, 2])
            with col_meta:
                st.markdown(f"**`{row['handle']}`**")
                st.caption(f"Source: `{row['source_id']}`")
                st.caption(f"Observed: `{row['observed_at']}`")
            with col_val:
                st.markdown(f"**Identifier Type:** `{row['identifier_type']}`")
                st.code(row["identifier_value"], language="text")
                with st.expander("📄 View Verbatim Source Artifact", expanded=False):
                    art = get_artifact(row["artifact_id"])
                    if art:
                        st.caption(f"URL: `{art['url']}` | SHA-256: `{art['content_hash']}`")
                        st.code(art["raw_content"], language="html")
