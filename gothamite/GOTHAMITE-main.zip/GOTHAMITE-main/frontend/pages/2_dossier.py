import sys
from pathlib import Path

# Ensure repository root is on sys.path for multi-page execution
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import streamlit as st
import pandas as pd

try:
    from frontend.api_client import (
        search_entities,
        get_persona_dossier,
        get_all_personas,
        get_artifact,
        format_score_badge,
    )
except ModuleNotFoundError:
    from api_client import (
        search_entities,
        get_persona_dossier,
        get_all_personas,
        get_artifact,
        format_score_badge,
    )

st.set_page_config(page_title="Actor Dossier | GOTHAMITE", page_icon="👤", layout="wide")

st.title("👤 Actor Dossier & Entity Search")
st.caption("Deep profile analysis, digital fingerprints, cross-source linkages, and observation history.")

# 1. Multi-vector Search Section
st.markdown("### 🔎 Search Intelligence Database")
search_q = st.text_input(
    "Search across handles, normalized PGP fingerprints, or cryptocurrency wallets:",
    placeholder="e.g. nightjar, 9F2A4C81..., 1Hx4kQ9...",
)

selected_persona_id = None

if search_q.strip():
    search_results = search_entities(search_q.strip())
    results_list = search_results.get("results", [])
    st.markdown(f"**Found {len(results_list)} matching persona(s):**")
    
    if results_list:
        cols = st.columns(min(len(results_list), 4))
        for idx, item in enumerate(results_list):
            with cols[idx % len(cols)]:
                with st.container(border=True):
                    st.markdown(f"**Handle:** `{item['handle']}`")
                    st.caption(f"Source: `{item['source_id']}`")
                    st.caption(f"Matched on: `{item['match_reason']}`")
                    if st.button("Inspect Dossier", key=f"btn_search_{item['persona_id']}"):
                        st.session_state["dossier_persona_id"] = item["persona_id"]
                        selected_persona_id = item["persona_id"]

st.markdown("---")

# 2. Persona Selector
all_personas = get_all_personas()
persona_options = {
    f"{p['handle']} ({p['source_id']})": p["persona_id"]
    for p in all_personas
}

default_idx = 0
if "dossier_persona_id" in st.session_state:
    for i, pid in enumerate(persona_options.values()):
        if pid == st.session_state["dossier_persona_id"]:
            default_idx = i
            break

selected_label = st.selectbox(
    "Or select a monitored persona directly:",
    list(persona_options.keys()),
    index=default_idx,
    key="persona_select_box",
)

persona_id_to_view = persona_options.get(selected_label)

if persona_id_to_view:
    dossier = get_persona_dossier(persona_id_to_view)

    if not dossier:
        st.error("Persona dossier could not be loaded.")
        st.stop()

    # Dossier Profile Header
    st.markdown(f"## 🗂️ Dossier: `{dossier['handle']}`")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Originating Source", dossier.get("source_id", "unknown"))
    c2.metric("Platform Type", dossier.get("source_type", "unknown").capitalize())
    c3.metric("Observed Activity Window", f"{dossier.get('first_seen', '')[:10]} to {dossier.get('last_seen', '')[:10]}")
    c4.metric("Scraped Post Count", f"{dossier.get('post_count', 1)}")

    st.markdown("---")

    col_left, col_right = st.columns([1, 1])

    # Left Column: Extracted Digital Identifiers
    with col_left:
        st.markdown("### 🔑 Cryptographic & Financial Identifiers")
        identifiers = dossier.get("identifiers", [])
        if not identifiers:
            st.info("No explicit identifiers extracted for this persona.")
        else:
            for ident in identifiers:
                with st.container(border=True):
                    itype = ident.get("type", "").upper()
                    st.markdown(f"**Type:** `{itype}`")
                    st.code(ident.get("value", ""), language="text")
                    st.caption(f"Observed: `{ident.get('observed_at')}`")
                    
                    art_id = ident.get("artifact_id")
                    if art_id:
                        with st.expander(f"Inspect Originating Artifact ({art_id[:8]}...)", expanded=False):
                            art = get_artifact(art_id)
                            if art:
                                st.markdown(f"**URL:** `{art.get('url')}`")
                                st.markdown(f"**SHA-256:** `{art.get('content_hash')}`")
                                st.code(art.get("raw_content", ""), language="html")

    # Right Column: Correlated Cross-Source Linkages
    with col_right:
        st.markdown("### 🔗 Correlated Cross-Source Personas")
        links = dossier.get("correlated_links", [])
        if not links:
            st.info("No cross-source relationships proposed or confirmed for this persona.")
        else:
            for lk in links:
                score_val = lk.get("score", 0.0)
                ltype = lk.get("type", "")
                status_val = lk.get("status", "proposed")
                direction = lk.get("direction", "outgoing")

                with st.container(border=True):
                    st.markdown(f"**Target Persona:** `{lk.get('target_handle')}` ({lk.get('target_source')})")
                    st.markdown(f"**Link Direction:** `{direction.upper()}` | **Type:** `{ltype}`")
                    st.markdown(f"**Confidence Score:** `{format_score_badge(score_val)}`")
                    st.markdown(f"**Review Status:** `{status_val.upper()}`")

    st.markdown("---")

    # Timeline & Observation History
    st.markdown("### 📜 Scraped Observation Timeline")
    timeline_items = dossier.get("timeline", [])
    if not timeline_items:
        st.info("No observation history recorded.")
    else:
        for item in timeline_items:
            with st.container(border=True):
                st.markdown(f"**Artifact ID:** `{item['artifact_id']}` | Collected: `{item['collected_at']}`")
                st.caption(f"URL: `{item['url']}`")
                st.code(item.get("snippet", ""), language="html")
