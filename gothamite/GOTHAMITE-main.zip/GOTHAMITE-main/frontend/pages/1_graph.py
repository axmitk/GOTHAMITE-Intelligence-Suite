import sys
from pathlib import Path

# Ensure repository root is on sys.path for multi-page execution
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import streamlit as st
import streamlit.components.v1 as components
from pyvis.network import Network
import pandas as pd

try:
    from frontend.api_client import (
        get_graph,
        get_edge_details,
        update_edge_status,
        get_artifact,
        format_score_badge,
    )
except ModuleNotFoundError:
    from api_client import (
        get_graph,
        get_edge_details,
        update_edge_status,
        get_artifact,
        format_score_badge,
    )

st.set_page_config(page_title="Relationship Graph | GOTHAMITE", page_icon="🕸️", layout="wide")

st.title("🕸️ Threat Actor Relationship Graph")
st.caption("Interactive cross-source persona correlation topology. Select an edge to inspect auditable evidence provenance.")

# Color map for sources
SOURCE_COLORS = {
    "forum-alpha": "#3498db",       # Blue
    "marketplace-beta": "#e67e22",   # Orange
    "forum-gamma": "#2ecc71",       # Green
}
DEFAULT_NODE_COLOR = "#95a5a6"

# Fetch latest graph state
graph_data = get_graph()
nodes = graph_data.get("nodes", [])
edges = graph_data.get("edges", [])

if not nodes:
    st.warning("No personas found in intelligence store. Seed data or run scrapers first.")
    st.stop()

# Layout: Left column (Graph Visualization), Right column (Evidence Panel)
col_graph, col_inspector = st.columns([3, 2])

with col_graph:
    st.markdown("### 🌐 Correlation Topology")
    
    # Render Legend
    l1, l2, l3 = st.columns(3)
    l1.markdown("🔵 **forum-alpha**")
    l2.markdown("🟠 **marketplace-beta**")
    l3.markdown("🟢 **forum-gamma**")

    # Build PyVis Network
    net = Network(height="520px", width="100%", bgcolor="#0e1117", font_color="white")
    net.force_atlas_2based()

    # Add Nodes
    for n in nodes:
        source_id = n.get("source_id", "")
        color = SOURCE_COLORS.get(source_id, DEFAULT_NODE_COLOR)
        label = f"{n.get('handle')}\n({source_id})"
        title = f"Persona: {n.get('handle')}<br>Source: {source_id}<br>Posts: {n.get('post_count', 1)}"
        net.add_node(
            n["id"],
            label=label,
            title=title,
            color=color,
            size=25,
            shape="dot",
        )

    # Add Edges
    for e in edges:
        score = e.get("score", 0.0)
        etype = e.get("type", "same_actor_suspected")
        status = e.get("status", "proposed")
        
        # Edge styling
        if etype == "transacted_with":
            color = "#f1c40f"  # Yellow for transactions
            width = 2
            dashes = True
        else:
            color = "#e74c3c" if score >= 0.80 else "#3498db"
            width = max(2, int(score * 8))
            dashes = False

        title = f"Type: {etype}<br>Score: {score:.2f}<br>Status: {status}"
        net.add_edge(
            e["from_node"],
            e["to_node"],
            value=width,
            title=title,
            color=color,
            dashes=dashes,
        )

    # Generate and render HTML
    try:
        html = net.generate_html()
        components.html(html, height=530)
    except Exception as err:
        st.error(f"Error rendering interactive graph: {err}")

with col_inspector:
    st.markdown("### 🔍 Edge Evidence Inspector")

    if not edges:
        st.info("No active relationships to inspect.")
    else:
        # Edge selector dropdown
        edge_options = {
            f"{e['from_handle']} ➔ {e['to_handle']} ({e['type']}, {e['score']:.2f})": e["id"]
            for e in edges
        }
        selected_edge_label = st.selectbox(
            "Select an edge to inspect evidence:",
            list(edge_options.keys()),
            key="selected_edge_dropdown",
        )
        selected_rel_id = edge_options[selected_edge_label]

        # Fetch complete evidence details
        edge_details = get_edge_details(selected_rel_id)

        if edge_details:
            score = edge_details.get("score", 0.0)
            status_val = edge_details.get("status", "proposed")
            link_type = edge_details.get("type", "")

            st.markdown(f"**Link:** `{edge_details['from_persona']['handle']}` ➔ `{edge_details['to_persona']['handle']}`")
            st.markdown(f"**Relationship Type:** `{link_type}`")
            st.markdown(f"**Confidence Score:** `{format_score_badge(score)}`")
            st.markdown(f"**Analyst Review Status:** `{status_val.upper()}`")

            # Analyst Review Actions (Confirm / Reject)
            btn_col1, btn_col2 = st.columns(2)
            with btn_col1:
                if st.button("✅ Confirm Link", key=f"confirm_{selected_rel_id}", use_container_width=True):
                    update_edge_status(selected_rel_id, "confirmed")
                    st.success("Link status updated to CONFIRMED.")
                    st.rerun()
            with btn_col2:
                if st.button("❌ Reject Link", key=f"reject_{selected_rel_id}", use_container_width=True):
                    update_edge_status(selected_rel_id, "rejected")
                    st.warning("Link REJECTED. Edge hidden from graph topology.")
                    st.rerun()

            st.markdown("#### Evidence Trail & Signals")
            evidence_list = edge_details.get("evidence", [])
            if not evidence_list:
                st.info("No evidence records attached to this link.")
            else:
                for idx, ev in enumerate(evidence_list):
                    is_supporting = ev.get("direction") == "supporting"
                    sign = "+" if is_supporting else "−"
                    color_marker = "🟢" if is_supporting else "🔴"
                    
                    with st.container(border=True):
                        st.markdown(
                            f"{color_marker} **{ev.get('signal_type', '').upper()}** | "
                            f"Weight: `{sign}{abs(ev.get('weight', 0.0)):.2f}` | "
                            f"Direction: `{ev.get('direction', '').upper()}`"
                        )
                        st.write(f"*{ev.get('note')}*")

                        art_id = ev.get("artifact_id")
                        if art_id:
                            with st.expander(f"📄 View Source Artifact Provenance ({art_id[:8]}...)", expanded=False):
                                art = get_artifact(art_id)
                                if art:
                                    st.markdown(f"**Source Host:** `{art.get('source_id')}`")
                                    st.markdown(f"**URL:** `{art.get('url')}`")
                                    st.markdown(f"**SHA-256:** `{art.get('content_hash')}`")
                                    st.markdown(f"**Collected At:** `{art.get('collected_at')}`")
                                    st.markdown(f"**Relay Chain:** `{', '.join(art.get('relay_path', []))}`")
                                    st.markdown("**Verbatim Scraped Text (Escaped Inert Content):**")
                                    # Security Boundary: Raw dark web HTML is rendered as inert escaped code block
                                    st.code(art.get("raw_content", ""), language="html")
                                else:
                                    st.error("Artifact not found in Evidence Locker.")
